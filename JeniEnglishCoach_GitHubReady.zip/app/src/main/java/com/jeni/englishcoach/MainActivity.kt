package com.jeni.englishcoach

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*

data class Lesson(val title:String,val content:String,val practice:String)
val lessons = listOf(
Lesson("Grammar & Sentence Formation","Correct sentence structure, tenses, articles, prepositions and questions.","Rewrite: What I have to do today?"),
Lesson("Workplace Vocabulary","Practical vocabulary for support, operations, meetings and client communication.","Use: clarify, prioritize, coordinate, resolve, follow up."),
Lesson("Speaking Trainer","Practice introductions, work updates, problems, questions, opinions, meetings and presentations.","Speak for 60 seconds: Give today's work update."),
Lesson("Corporate Communication","Turn simple sentences into clear, professional workplace English.","Instead of “There is a problem”, say “We’ve identified an issue and are looking into it.”"),
Lesson("Voice & Pronunciation","Practice pace, pauses, clarity, stress and professional delivery.","Read: “I’ll review this and get back to you by tomorrow.”"),
Lesson("Daily Review","Review mistakes, vocabulary and speaking practice.","Write three sentences you want to say more naturally.")
)

@Composable
fun App(){
 val nav=rememberNavController()
 Scaffold(bottomBar={
  NavigationBar{
   NavigationBarItem(selected=false,onClick={nav.navigate("today")},icon={},label={Text("Today")})
   NavigationBarItem(selected=false,onClick={nav.navigate("lessons")},icon={},label={Text("Lessons")})
   NavigationBarItem(selected=false,onClick={nav.navigate("progress")},icon={},label={Text("Progress")})
  }
 }){p->NavHost(nav,"today",Modifier.padding(p)){
  composable("today"){Today(nav)}
  composable("lessons"){Lessons(nav)}
  composable("lesson/{i}"){b->LessonPage(lessons[b.arguments?.getString("i")?.toIntOrNull()?:0])}
  composable("progress"){Progress()}
 }}
}

@Composable fun Today(nav:NavHostController){
 Column(Modifier.fillMaxSize().padding(20.dp)){
  Text("Jeni English Coach",style=MaterialTheme.typography.headlineMedium)
  Text("Your 60-minute workplace English trainer")
  Spacer(Modifier.height(20.dp))
  Card{Column(Modifier.padding(18.dp)){
   Text("Today's 60-minute plan",style=MaterialTheme.typography.titleLarge)
   Text("10 min Grammar • 10 min Vocabulary • 15 min Speaking\n10 min Corporate • 10 min Voice • 5 min Review")
  }}
  Spacer(Modifier.height(14.dp))
  lessons.forEachIndexed{i,l->Button({nav.navigate("lesson/$i")},Modifier.fillMaxWidth().padding(3.dp)){Text(l.title)}}
 }
}
@Composable fun Lessons(nav:NavHostController){
 LazyColumn(Modifier.padding(16.dp)){
  item{Text("Training Library",style=MaterialTheme.typography.headlineSmall)}
  lessons.forEachIndexed{i,l->item{Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(16.dp)){
   Text(l.title,style=MaterialTheme.typography.titleMedium);Text(l.content)
   OutlinedButton({nav.navigate("lesson/$i")}){Text("Practice")}
  }}}}
 }
}
@Composable fun LessonPage(l:Lesson){
 var a by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().padding(20.dp)){
  Text(l.title,style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(12.dp))
  Text(l.content);Spacer(Modifier.height(16.dp));Text("Practice",style=MaterialTheme.typography.titleLarge)
  Text(l.practice);Spacer(Modifier.height(12.dp))
  OutlinedTextField(a,{a=it},Modifier.fillMaxWidth().height(150.dp),label={Text("Your answer")})
  Spacer(Modifier.height(10.dp));Button({},Modifier.fillMaxWidth()){Text("Save Practice")}
 }
}
@Composable fun Progress(){
 Column(Modifier.fillMaxSize().padding(20.dp)){
  Text("Progress",style=MaterialTheme.typography.headlineSmall);Spacer(Modifier.height(16.dp))
  Text("Levels: Basic Workplace → Confident Speaker → Professional Communicator → Client-ready → Leadership")
  Spacer(Modifier.height(16.dp))
  listOf("Grammar","Vocabulary","Speaking","Fluency","Corporate English","Pronunciation","Voice","Confidence").forEach{
   Text(it);LinearProgressIndicator(progress={0f},Modifier.fillMaxWidth().padding(vertical=7.dp))
  }
 }
}
class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MaterialTheme{App()}}}
}
