# Jeni English Coach — phone-only cloud APK build

This project includes a GitHub Actions workflow. After uploading the project to a GitHub repository, open the repository's Actions tab and run **Build Jeni English Coach APK**. When the build completes, download the **JeniEnglishCoach-debug-apk** artifact and install the APK on your Android phone.

The workflow uses Gradle and JDK 17 on GitHub's cloud runner.
