# Phone-only GitHub build

1. Create a GitHub repository.
2. Extract this ZIP before uploading if your GitHub mobile interface does not support folder upload.
3. Upload the CONTENTS of this folder to the repository root (not the outer folder itself).
4. Open Actions.
5. Select "Build Jeni English Coach APK".
6. Tap "Run workflow".
7. When it finishes, open the run and download the artifact "JeniEnglishCoach-APK".
8. Extract the artifact ZIP and install app-debug.apk on Android.

Never add passwords, API keys, signing keys, or other secrets to this repository.
